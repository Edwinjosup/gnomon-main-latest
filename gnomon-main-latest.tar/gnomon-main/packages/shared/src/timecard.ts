import { z } from 'zod';

export const WorkLocationSchema = z.enum(['WFO', 'WFH']);
export type WorkLocation = z.infer<typeof WorkLocationSchema>;

export const ShiftCodeSchema = z.enum(['M', 'R', 'A', 'N']);
export type ShiftCode = z.infer<typeof ShiftCodeSchema>;

export interface ShiftTemplate {
  code: ShiftCode;
  label: string;
  bufferLabel: string;
  bufferStartHour: number;
  bufferEndHour: number;
}

export const SHIFT_TEMPLATES: Record<ShiftCode, ShiftTemplate> = {
  M: {
    code: 'M',
    label: 'Morning',
    bufferLabel: '6:00 AM – 8:00 AM',
    bufferStartHour: 6,
    bufferEndHour: 8,
  },
  R: {
    code: 'R',
    label: 'Regular',
    bufferLabel: '8:00 AM – 10:00 AM',
    bufferStartHour: 8,
    bufferEndHour: 10,
  },
  A: {
    code: 'A',
    label: 'Afternoon',
    bufferLabel: '1:00 PM – 3:00 PM',
    bufferStartHour: 13,
    bufferEndHour: 15,
  },
  N: {
    code: 'N',
    label: 'Night',
    bufferLabel: '3:00 PM – 12:00 AM',
    bufferStartHour: 15,
    bufferEndHour: 24,
  },
};

export const ShiftBufferStatusSchema = z.enum(['within_buffer', 'outside_buffer', 'unassigned']);
export type ShiftBufferStatus = z.infer<typeof ShiftBufferStatusSchema>;

export function evaluateShiftBuffer(
  shiftCode: ShiftCode | null | undefined,
  instantIso: string | Date | null | undefined,
): {
  shiftCode: ShiftCode | null;
  shiftLabel: string | null;
  bufferLabel: string | null;
  bufferStatus: ShiftBufferStatus;
} {
  if (!shiftCode || !(shiftCode in SHIFT_TEMPLATES)) {
    return {
      shiftCode: null,
      shiftLabel: null,
      bufferLabel: null,
      bufferStatus: 'unassigned',
    };
  }
  const template = SHIFT_TEMPLATES[shiftCode];
  if (!instantIso) {
    return {
      shiftCode: template.code,
      shiftLabel: template.label,
      bufferLabel: template.bufferLabel,
      bufferStatus: 'outside_buffer',
    };
  }
  const date = instantIso instanceof Date ? instantIso : new Date(instantIso);
  const parts = new Intl.DateTimeFormat('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
    timeZone: 'Asia/Kolkata',
  }).formatToParts(date);
  const hour = Number(parts.find((p) => p.type === 'hour')?.value ?? '0');
  const minute = Number(parts.find((p) => p.type === 'minute')?.value ?? '0');
  const totalMinutes = hour * 60 + minute;
  const startMinutes = template.bufferStartHour * 60;
  const endMinutes = template.bufferEndHour * 60;
  const within = totalMinutes >= startMinutes && totalMinutes <= endMinutes;

  return {
    shiftCode: template.code,
    shiftLabel: template.label,
    bufferLabel: template.bufferLabel,
    bufferStatus: within ? 'within_buffer' : 'outside_buffer',
  };
}

export const StartTimecardRequestSchema = z.object({
  shiftCode: ShiftCodeSchema,
  location: WorkLocationSchema,
});
export type StartTimecardRequest = z.infer<typeof StartTimecardRequestSchema>;

export const WorkSessionStatusSchema = z.enum([
  'running',
  'completed',
  'force_stopped',
  'regularised',
]);
export type WorkSessionStatus = z.infer<typeof WorkSessionStatusSchema>;

export const WorkSessionDtoSchema = z.object({
  id: z.string(),
  workDate: z.string().date(),
  startedAt: z.string().datetime(),
  stoppedAt: z.string().datetime().nullable(),
  durationMinutes: z.number().int().nonnegative().nullable(),
  status: WorkSessionStatusSchema,
  shiftCode: ShiftCodeSchema.nullable(),
  location: WorkLocationSchema.nullable(),
});
export type WorkSessionDto = z.infer<typeof WorkSessionDtoSchema>;

export const TodayTimecardSchema = z.object({
  workDate: z.string().date(),
  state: z.enum(['not_started', 'running', 'completed']),
  activeSession: WorkSessionDtoSchema.nullable(),
  sessions: z.array(WorkSessionDtoSchema),
  totalTrackedSeconds: z.number().int().nonnegative(),
  serverNow: z.string().datetime(),
});
export type TodayTimecard = z.infer<typeof TodayTimecardSchema>;

export const OverviewShiftRecordSchema = z.object({
  id: z.string(),
  employeeId: z.string(),
  employeeCode: z.string(),
  employeeName: z.string(),
  department: z.string(),
  shiftCode: ShiftCodeSchema,
  shiftLabel: z.string(),
  location: WorkLocationSchema.nullable(),
  bufferLabel: z.string(),
  bufferStatus: ShiftBufferStatusSchema,
  startedAt: z.string().datetime(),
  stoppedAt: z.string().datetime().nullable(),
  durationMinutes: z.number().int().nonnegative().nullable(),
  status: WorkSessionStatusSchema,
});
export type OverviewShiftRecordDto = z.infer<typeof OverviewShiftRecordSchema>;

export const OverviewShiftsResponseSchema = z.object({
  visible: z.boolean(),
  workDate: z.string().date(),
  records: z.array(OverviewShiftRecordSchema),
});
export type OverviewShiftsResponse = z.infer<typeof OverviewShiftsResponseSchema>;
