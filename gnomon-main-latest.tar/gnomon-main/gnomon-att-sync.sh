#!/usr/bin/env bash
set -u

# ==============================================================================
# Gnomon Biometric Attendance Synchronization & Ingestion Pipeline
# Host: hb-leave-mgmt | Target: Gnomon API (127.0.0.1:8081)
# ==============================================================================

SMB_MOUNT_DIR="/mnt/attendance"
WATCH_DIR="/opt/att_csv"
ARCHIVE_DIR="/opt/att_csv/archive"
FAILED_DIR="/opt/att_csv/failed"
LOG_FILE="/var/log/gnomon-att-sync.log"

API_BASE_URL="http://127.0.0.1:8081/api/v1"
ADMIN_EMAIL=""
ADMIN_PASSWORD=''

mkdir -p "$WATCH_DIR" "$ARCHIVE_DIR" "$FAILED_DIR"

log() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# --- 1. Fetch Latest CSV from SMB Mount ---
if ! mountpoint -q "$SMB_MOUNT_DIR"; then
  log "Mount $SMB_MOUNT_DIR is down. Attempting to mount..."
  mount "$SMB_MOUNT_DIR" 2>/dev/null
  if ! mountpoint -q "$SMB_MOUNT_DIR"; then
    log "ERROR: Could not mount $SMB_MOUNT_DIR."
  fi
fi

if mountpoint -q "$SMB_MOUNT_DIR"; then
  # Find the single latest CSV by modification time
  LATEST_SMB_FILE=$(find "$SMB_MOUNT_DIR" -maxdepth 1 -type f \( -iname "*.csv" \) -printf '%T@ %p\n' 2>/dev/null | sort -n | tail -1 | cut -d' ' -f2-)

  if [ -n "$LATEST_SMB_FILE" ] && [ -f "$LATEST_SMB_FILE" ]; then
    LATEST_NAME=$(basename "$LATEST_SMB_FILE")

    # Ingest only if not already archived or currently staged
    # Checks whether $LATEST_NAME exists anywhere in archive or watch dir
    if [ ! -f "$WATCH_DIR/$LATEST_NAME" ] && ! ls "$ARCHIVE_DIR"/*"$LATEST_NAME" >/dev/null 2>&1; then
      log "New dump found on SMB: $LATEST_NAME. Copying to $WATCH_DIR..."
      cp "$LATEST_SMB_FILE" "$WATCH_DIR/"
    else
      log "Latest file ($LATEST_NAME) has already been processed or is staged."
    fi
  else
    log "No CSV punch records found in $SMB_MOUNT_DIR."
  fi
fi

# --- 2. Check Staged Files in WATCH_DIR ---
shopt -s nullglob
FILES=("$WATCH_DIR"/*.csv "$WATCH_DIR"/*.CSV "$WATCH_DIR"/*.xls "$WATCH_DIR"/*.xlsx "$WATCH_DIR"/*.XLS "$WATCH_DIR"/*.XLSX)
shopt -u nullglob

if [ ${#FILES[@]} -eq 0 ]; then
  exit 0
fi

log "Found ${#FILES[@]} attendance file(s) in $WATCH_DIR."

# --- 3. Authenticate to Gnomon API ---
LOGIN_RES=$(curl -s -X POST "${API_BASE_URL}/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"${ADMIN_EMAIL}\",\"password\":\"${ADMIN_PASSWORD}\"}")

ACCESS_TOKEN=$(echo "$LOGIN_RES" | grep -o '"accessToken":"[^"]*' | cut -d'"' -f4 || true)

if [ -z "$ACCESS_TOKEN" ]; then
  log "ERROR: Authentication failed. Response: $LOGIN_RES"
  exit 1
fi

# --- 4. Process and Upload Files ---
for FILE in "${FILES[@]}"; do
  [ -f "$FILE" ] || continue
  FILENAME=$(basename "$FILE")
  EXT="${FILENAME##*.}"
  EXT_LOWER=$(echo "$EXT" | tr '[:upper:]' '[:lower:]')

  log "Processing: $FILENAME"

  if [ "$EXT_LOWER" = "csv" ]; then
    ENDPOINT="${API_BASE_URL}/imports/attendance/biometric/csv?mode=add"
    CONTENT_TYPE="text/csv"

    AWK_OUT=$(awk -F',' '
      BEGIN { OFS="," }
      { gsub(/\r/, "", $0) }
      NR==1 && ($1 ~ /employee_code|emp_id/i) { next }
      NF >= 4 {
        emp = $1
        gsub(/^[ \t]+|[ \t]+$/, "", emp)

        gsub(/^[ \t]+|[ \t]+$/, "", $2)
        split($2, parts_date, "/")
        if (length(parts_date[3]) == 4) {
          iso_date = parts_date[3] "-" sprintf("%02d", parts_date[1]) "-" sprintf("%02d", parts_date[2])
        } else {
          iso_date = $2
        }

        time_val = $3
        gsub(/^[ \t]+|[ \t]+$/, "", time_val)

        ev = tolower($4)
        gsub(/^[ \t]+|[ \t]+$/, "", ev)

        if (length(emp) > 0 && length(iso_date) > 0 && length(time_val) > 0) {
          dates[iso_date] = 1
          key = emp SUBSEP iso_date
          keys[key] = emp SUBSEP iso_date

          if (ev ~ /^in/) {
            if (!(key in first_in) || time_val < first_in[key]) {
              first_in[key] = time_val
            }
          } else if (ev ~ /^out/) {
            if (!(key in last_out) || time_val > last_out[key]) {
              last_out[key] = time_val
            }
          }
        }
      }
      END {
        d_str = ""
        for (date_item in dates) { d_str = d_str " " date_item }
        print "#DATES#" d_str

        print "date,employee_code,in_time,out_time"
        for (k in keys) {
          split(keys[k], parts, SUBSEP)
          emp_code = parts[1]
          w_date = parts[2]
          in_t = (k in first_in) ? first_in[k] : ""
          out_t = (k in last_out) ? last_out[k] : ""
          if (in_t != "" || out_t != "") {
            print w_date, emp_code, in_t, out_t
          }
        }
      }
    ' "$FILE")

    TARGET_DATES=$(echo "$AWK_OUT" | grep "^#DATES#" | sed 's/^#DATES# //' || true)
    PAYLOAD=$(echo "$AWK_OUT" | grep -v "^#DATES#")

    # Purge previous biometric events for these dates so the new run overwrites cleanly
    if [ -n "$TARGET_DATES" ]; then
      for D in $TARGET_DATES; do
        docker exec -i gnomon-main-mongo-1 mongo gnomon --quiet --eval \
          "db.attendanceevents.deleteMany({ source: 'biometric', workDate: '$D' });" >/dev/null 2>&1 || true
      done
    fi

    UPLOAD_RES=$(curl -s -w "\nHTTP_STATUS:%{http_code}" -X POST "$ENDPOINT" \
      -H "Authorization: Bearer $ACCESS_TOKEN" \
      -H "Content-Type: $CONTENT_TYPE" \
      -H "x-file-name: $FILENAME" \
      --data-binary "$PAYLOAD")

  else
    ENDPOINT="${API_BASE_URL}/imports/attendance/access-card/door-workbook?mode=add"
    CONTENT_TYPE="application/octet-stream"

    UPLOAD_RES=$(curl -s -w "\nHTTP_STATUS:%{http_code}" -X POST "$ENDPOINT" \
      -H "Authorization: Bearer $ACCESS_TOKEN" \
      -H "Content-Type: $CONTENT_TYPE" \
      -H "x-file-name: $FILENAME" \
      --data-binary "@$FILE")
  fi

  HTTP_STATUS=$(echo "$UPLOAD_RES" | grep "HTTP_STATUS:" | cut -d':' -f2 || echo "000")
  BODY=$(echo "$UPLOAD_RES" | sed '/HTTP_STATUS:/d')

  if [[ "$HTTP_STATUS" =~ ^20[01]$ ]]; then
    log "SUCCESS: $FILENAME processed and overwritten successfully (HTTP $HTTP_STATUS)."
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)
    mv "$FILE" "$ARCHIVE_DIR/${TIMESTAMP}_${FILENAME}"
  else
    log "FAILED: $FILENAME returned HTTP $HTTP_STATUS: $BODY"
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)
    mv "$FILE" "$FAILED_DIR/${TIMESTAMP}_${FILENAME}"
  fi
done

log "Run completed."
