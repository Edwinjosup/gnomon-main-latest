import { SHIFT_TEMPLATES, type ShiftCode } from '@gnomon/shared';
import {
  Alert,
  Box,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import { Clock3, UsersRound, MapPin } from 'lucide-react';
import { useMemo, useState } from 'react';

import { PageHeader } from '../components/data-view/PageHeader';
import { formatIndiaTime, useOverviewShifts } from '../lib/timecard';

function todayIstDate(): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    timeZone: 'Asia/Kolkata',
  }).formatToParts(new Date());
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? '';
  return `${get('year')}-${get('month')}-${get('day')}`;
}

export function EmployeesTimeSheetPage() {
  const [selectedDate, setSelectedDate] = useState<string>(todayIstDate);
  const [search, setSearch] = useState('');
  const [shiftFilter, setShiftFilter] = useState<'ALL' | ShiftCode>('ALL');
  const shiftsQuery = useOverviewShifts(selectedDate);

  const filteredRecords = useMemo(() => {
    const term = search.trim().toLowerCase();
    return (shiftsQuery.data?.records ?? []).filter((record) => {
      const matchesShift = shiftFilter === 'ALL' || record.shiftCode === shiftFilter;
      const matchesTerm =
        !term ||
        [record.employeeName, record.employeeCode, record.department, record.shiftLabel, record.location]
          .join(' ')
          .toLowerCase()
          .includes(term);
      return matchesShift && matchesTerm;
    });
  }, [search, shiftFilter, shiftsQuery.data?.records]);

  return (
    <Stack spacing={2.5} sx={{ width: '100%', maxWidth: 1500, mx: 'auto' }}>
      <PageHeader
        eyebrow="WORKFORCE SHIFT & TIMECARD"
        title="Employees time sheet"
        meta={`Shift selections, timecard sessions, and buffer validation for ${shiftsQuery.data?.workDate ?? selectedDate}`}
        action={
          <TextField
            size="small"
            type="date"
            label="Work date"
            value={selectedDate}
            onChange={(event) => setSelectedDate(event.target.value)}
            slotProps={{ inputLabel: { shrink: true } }}
          />
        }
      />

      {shiftsQuery.error && <Alert severity="error">{shiftsQuery.error.message}</Alert>}

      <Card sx={{ boxShadow: 'none' }}>
        <CardContent sx={{ p: { xs: 2.5, md: 3 } }}>
          <Stack direction={{ xs: 'column', sm: 'row' }} sx={{ justifyContent: 'space-between', alignItems: { sm: 'center' }, gap: 2, mb: 2.5 }}>
            <Stack direction="row" sx={{ alignItems: 'center', gap: 1.5 }}>
              <Box sx={{ width: 40, height: 40, display: 'grid', placeItems: 'center', borderRadius: 2.25, bgcolor: '#edf7f8', color: '#117f8c' }}>
                <UsersRound size={19} />
              </Box>
              <Box>
                <Typography sx={{ fontSize: 15.5, fontWeight: 820 }}>
                  Employee shifts &amp; timecard sessions
                </Typography>
                <Typography sx={{ color: 'text.secondary', fontSize: 11.5 }}>
                  Showing {filteredRecords.length} record{filteredRecords.length === 1 ? '' : 's'}
                </Typography>
              </Box>
            </Stack>
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
              <TextField size="small" placeholder="Search name, code, or dept..." value={search} onChange={(event) => setSearch(event.target.value)} sx={{ minWidth: 230 }} />
              <FormControl size="small" sx={{ minWidth: 170 }}>
                <InputLabel id="emp-ts-shift-filter">Shift</InputLabel>
                <Select labelId="emp-ts-shift-filter" value={shiftFilter} label="Shift" onChange={(event) => setShiftFilter(event.target.value as 'ALL' | ShiftCode)}>
                  <MenuItem value="ALL">All shifts</MenuItem>
                  {Object.values(SHIFT_TEMPLATES).map((shift) => (
                    <MenuItem key={shift.code} value={shift.code}>
                      {shift.code} — {shift.label}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Stack>
          </Stack>

          <TableContainer sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 2 }}>
            <Table size="small">
              <TableHead sx={{ bgcolor: '#f6f8fa' }}>
                <TableRow>
                  <TableCell sx={{ fontWeight: 750 }}>Employee</TableCell>
                  <TableCell sx={{ fontWeight: 750 }}>Department</TableCell>
                  <TableCell sx={{ fontWeight: 750 }}>Shift</TableCell>
                  <TableCell sx={{ fontWeight: 750 }}>Location</TableCell>
                  <TableCell sx={{ fontWeight: 750 }}>Buffer validation</TableCell>
                  <TableCell sx={{ fontWeight: 750 }}>Timecard start (IST)</TableCell>
                  <TableCell sx={{ fontWeight: 750 }}>Timecard stop (IST)</TableCell>
                  <TableCell sx={{ fontWeight: 750 }}>Duration</TableCell>
                  <TableCell sx={{ fontWeight: 750 }}>Status</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {shiftsQuery.isLoading ? (
                  <TableRow>
                    <TableCell colSpan={9} align="center" sx={{ py: 4 }}>
                      <CircularProgress size={22} />
                    </TableCell>
                  </TableRow>
                ) : filteredRecords.length ? (
                  filteredRecords.map((record) => (
                    <TableRow key={record.id} hover>
                      <TableCell>
                        <Typography sx={{ fontSize: 13, fontWeight: 750 }}>{record.employeeName}</Typography>
                        <Typography sx={{ fontSize: 11, color: 'text.secondary' }}>{record.employeeCode}</Typography>
                      </TableCell>
                      <TableCell sx={{ fontSize: 12.5 }}>{record.department}</TableCell>
                      <TableCell>
                        <Chip size="small" color="primary" variant="outlined" label={`${record.shiftCode} · ${record.shiftLabel}`} sx={{ fontWeight: 750 }} />
                      </TableCell>
                      <TableCell sx={{ fontSize: 12.5 }}>
                         {record.location ? (
                           <Stack direction="row" spacing={0.5} sx={{ alignItems: "center" }}>
                             <MapPin size={12} />
                             <span>{record.location === 'WFO' ? 'Office' : 'Home'}</span>
                           </Stack>
                         ) : '—'}
                      </TableCell>
                      <TableCell>
                        <Chip size="small" label={record.bufferStatus === 'within_buffer' ? 'Within buffer' : 'Outside buffer'} color={record.bufferStatus === 'within_buffer' ? 'success' : 'warning'} variant="outlined" sx={{ fontWeight: 700, fontSize: 11 }} />
                      </TableCell>
                      <TableCell sx={{ fontSize: 12.5 }}>{formatIndiaTime(record.startedAt)}</TableCell>
                      <TableCell sx={{ fontSize: 12.5 }}>{formatIndiaTime(record.stoppedAt)}</TableCell>
                      <TableCell sx={{ fontSize: 12.5 }}>{record.status === 'running' ? 'In progress' : `${record.durationMinutes ?? 0} min`}</TableCell>
                      <TableCell>
                        <Chip size="small" icon={<Clock3 size={12} />} label={record.status === 'running' ? 'Active' : record.status} color={record.status === 'running' ? 'success' : 'default'} variant={record.status === 'running' ? 'filled' : 'outlined'} sx={{ textTransform: 'capitalize', fontSize: 11 }} />
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={9} align="center" sx={{ py: 4, color: 'text.secondary', fontSize: 12.5 }}>
                      No employee shift timecard records found for this date.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>
      </Card>
    </Stack>
  );
}
