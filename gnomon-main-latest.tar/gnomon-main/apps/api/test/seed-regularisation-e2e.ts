import bcrypt from 'bcryptjs';
import { z } from 'zod';

import { env } from '../src/config/env.js';
import { connectDatabase, disconnectDatabase } from '../src/db/mongoose.js';
import { User } from '../src/modules/auth/user.model.js';
import { Employee } from '../src/modules/employees/employee.model.js';
import { EmployeeLocationAssignment, Location } from '../src/modules/employees/location.model.js';
import { LeaveBalance, LeaveRequest } from '../src/modules/leaves/leave.model.js';
import { Holiday } from '../src/modules/policies/holiday.model.js';
import { DailyTimecard } from '../src/modules/reconciliation/daily-timecard.model.js';
import { RegularisationRequest } from '../src/modules/regularisations/regularisation.model.js';
import { RoleAssignment } from '../src/modules/roles/role.model.js';
import { ensureSystemRoles } from '../src/modules/roles/system-roles.js';
import { Show } from '../src/modules/shows/show.model.js';
import { TimeEntry } from '../src/modules/timesheets/time-entry.model.js';

const FixtureEnvSchema = z.object({
  E2E_EMPLOYEE_EMAIL: z
    .string()
    .email()
    .transform((value) => value.toLowerCase()),
  E2E_EMPLOYEE_PASSWORD: z.string().min(12),
  E2E_MANAGER_EMAIL: z
    .string()
    .email()
    .transform((value) => value.toLowerCase()),
  E2E_MANAGER_PASSWORD: z.string().min(12),
  E2E_HR_EMAIL: z
    .string()
    .email()
    .transform((value) => value.toLowerCase()),
  E2E_HR_PASSWORD: z.string().min(12),
});

function assertIsolatedTestDatabase(): void {
  const databaseName = new URL(env.MONGODB_URI).pathname.replace(/^\//, '');
  if (env.NODE_ENV !== 'test' || !databaseName.endsWith('_test')) {
    throw new Error('Workflow E2E fixtures may only be seeded into a *_test database');
  }
}

function currentIndiaYear(): number {
  return Number(
    new Intl.DateTimeFormat('en-CA', {
      year: 'numeric',
      timeZone: 'Asia/Kolkata',
    }).format(new Date()),
  );
}

async function upsertEmployee(
  employeeCode: string,
  email: string,
  firstName: string,
  lastName: string,
) {
  return Employee.findOneAndUpdate(
    { employeeCode },
    {
      $set: {
        email,
        firstName,
        lastName,
        timezone: 'Asia/Kolkata',
        locationId: null,
        status: 'active',
      },
    },
    { upsert: true, returnDocument: 'after', setDefaultsOnInsert: true },
  );
}

async function upsertUser(employeeId: unknown, email: string, password: string) {
  return User.findOneAndUpdate(
    { email },
    {
      $set: {
        employeeId,
        passwordHash: await bcrypt.hash(password, 4),
        status: 'active',
        tokenVersion: 0,
      },
    },
    { upsert: true, returnDocument: 'after', setDefaultsOnInsert: true },
  );
}

async function seedWorkflowFixtures(): Promise<void> {
  assertIsolatedTestDatabase();
  const input = FixtureEnvSchema.parse(process.env);
  await connectDatabase();

  const manager = await upsertEmployee('E2ERM001', input.E2E_MANAGER_EMAIL, 'Meera', 'Manager');
  const hr = await upsertEmployee('E2EHR001', input.E2E_HR_EMAIL, 'Harini', 'HR');
  const employee = await upsertEmployee('E2EEMP01', input.E2E_EMPLOYEE_EMAIL, 'Eshan', 'Artist');
  employee.reportingManagerId = manager._id;
  await employee.save();

  const employeeUser = await upsertUser(
    employee._id,
    input.E2E_EMPLOYEE_EMAIL,
    input.E2E_EMPLOYEE_PASSWORD,
  );
  const managerUser = await upsertUser(
    manager._id,
    input.E2E_MANAGER_EMAIL,
    input.E2E_MANAGER_PASSWORD,
  );
  const hrUser = await upsertUser(hr._id, input.E2E_HR_EMAIL, input.E2E_HR_PASSWORD);

  const fixtureEmployeeIds = [employee._id, manager._id, hr._id];
  const fixtureUserIds = [employeeUser._id, managerUser._id, hrUser._id];
  await Promise.all([
    RegularisationRequest.deleteMany({ employeeId: { $in: fixtureEmployeeIds } }),
    LeaveRequest.deleteMany({ employeeId: { $in: fixtureEmployeeIds } }),
    LeaveBalance.deleteMany({ employeeId: { $in: fixtureEmployeeIds } }),
    Holiday.deleteMany({}),
    DailyTimecard.deleteMany({ employeeId: { $in: fixtureEmployeeIds } }),
    RoleAssignment.deleteMany({ userId: { $in: fixtureUserIds } }),
    TimeEntry.deleteMany({}),
    Show.deleteMany({}),
    EmployeeLocationAssignment.deleteMany({ employeeId: { $in: fixtureEmployeeIds } }),
    Location.deleteMany({}),
  ]);

  const roles = await ensureSystemRoles();
  const employeeRole = roles.get('EMPLOYEE');
  const managerRole = roles.get('REPORTING_MANAGER');
  const showManagerRole = roles.get('SHOW_MANAGER');
  const hrRole = roles.get('HR');
  const attendanceRole = roles.get('ATTENDANCE_ADMIN');
  if (!employeeRole || !managerRole || !showManagerRole || !hrRole || !attendanceRole) {
    throw new Error('Required system roles could not be seeded');
  }

  const calendarShow = await Show.create({
    code: 'E2ECAL',
    name: 'Calendar Show',
    status: 'active',
    createdBy: managerUser._id,
  });
  await RoleAssignment.insertMany([
    {
      userId: employeeUser._id,
      roleId: employeeRole._id,
      scopeType: 'self',
      scopeIds: [employee._id],
      validFrom: new Date(),
      validUntil: null,
      grantedBy: null,
    },
    {
      userId: managerUser._id,
      roleId: employeeRole._id,
      scopeType: 'self',
      scopeIds: [manager._id],
      validFrom: new Date(),
      validUntil: null,
      grantedBy: null,
    },
    {
      userId: managerUser._id,
      roleId: managerRole._id,
      scopeType: 'direct_reports',
      scopeIds: [employee._id],
      validFrom: new Date(),
      validUntil: null,
      grantedBy: null,
    },
    {
      userId: managerUser._id,
      roleId: showManagerRole._id,
      scopeType: 'show',
      scopeIds: [calendarShow._id],
      validFrom: new Date(),
      validUntil: null,
      grantedBy: null,
    },
    {
      userId: hrUser._id,
      roleId: employeeRole._id,
      scopeType: 'self',
      scopeIds: [hr._id],
      validFrom: new Date(),
      validUntil: null,
      grantedBy: null,
    },
    {
      userId: hrUser._id,
      roleId: hrRole._id,
      scopeType: 'company',
      scopeIds: [],
      validFrom: new Date(),
      validUntil: null,
      grantedBy: null,
    },
    {
      userId: hrUser._id,
      roleId: attendanceRole._id,
      scopeType: 'company',
      scopeIds: [],
      validFrom: new Date(),
      validUntil: null,
      grantedBy: null,
    },
  ]);

  await LeaveBalance.insertMany(
    [
      ['casual', 12],
      ['sick', 10],
      ['earned', 15],
    ].map(([leaveType, entitledDays]) => ({
      employeeId: employee._id,
      leaveType,
      year: currentIndiaYear(),
      entitledDays,
      adjustedDays: 0,
      note: 'E2E fixture annual balance',
      updatedByUserId: hrUser._id,
    })),
  );

  process.stdout.write('Seeded isolated attendance, timesheet, leave, and policy E2E fixtures\n');
}

seedWorkflowFixtures()
  .then(disconnectDatabase)
  .catch(async (error: unknown) => {
    process.stderr.write(`${String(error)}\n`);
    await disconnectDatabase();
    process.exitCode = 1;
  });
