#!/usr/bin/env bash
set -euo pipefail
cd /opt/gnomon-main

python3 - <<'PY'
from pathlib import Path
import re, shutil, sys

for name in ("DashboardPage", "ModulePage"):
    p = Path(f"apps/web/src/pages/{name}.tsx")
    t = p.read_text()
    if "setLocation" in t:
        print(f"{name}: already patched, skipping")
        continue
    shutil.copy(p, str(p) + ".bak")

    # 1. state, right after selectedShift
    state = "  const [selectedShift, setSelectedShift] = useState<ShiftCode | ''>('');\n"
    if t.count(state) != 1:
        sys.exit(f"{name}: selectedShift state anchor not found exactly once")
    t = t.replace(state, state + "  const [location, setLocation] = useState<WorkLocation>('WFO');\n")

    # 2. pass the chosen location
    call = "timecard.start(selectedShift, 'WFO');"
    if t.count(call) != 1:
        sys.exit(f"{name}: start() call not found exactly once")
    t = t.replace(call, "timecard.start(selectedShift, location);")

     # 3. picker, inserted before the Start/Stop button (hidden while a session is running)
    m = list(re.finditer(r"^([ \t]*)<Button\n[ \t]*size=\"large\"", t, re.M))
    if len(m) != 1:
        sys.exit(f"{name}: button anchor not found exactly once ({len(m)})")
    ind = m[0].group(1)
    picker = (
        f"{ind}{{!timecard.timecard?.activeSession && (\n"
        f"{ind}  <FormControl size=\"small\" sx={{{{ minWidth: 150 }}}}>\n"
        f"{ind}    <InputLabel id=\"{name}-location-label\">Work location</InputLabel>\n"
        f"{ind}    <Select\n"
        f"{ind}      labelId=\"{name}-location-label\"\n"
        f"{ind}      value={{location}}\n"
        f"{ind}      label=\"Work location\"\n"
        f"{ind}      onChange={{(event) => setLocation(event.target.value as WorkLocation)}}\n"
        f"{ind}    >\n"
        f"{ind}      <MenuItem value=\"WFO\">Office (WFO)</MenuItem>\n"
        f"{ind}      <MenuItem value=\"WFH\">Home (WFH)</MenuItem>\n"
        f"{ind}    </Select>\n"
         f"{ind}  </FormControl>\n"
        f"{ind})}}\n\n"
    )
    t = t[:m[0].start()] + picker + t[m[0].start():]

    # 4. WorkLocation type import: append to the existing @gnomon/shared import
    imp = re.search(r"import \{([^}]*)\} from '@gnomon/shared';", t)
    if not imp:
        sys.exit(f"{name}: @gnomon/shared import not found")
    if "WorkLocation" not in imp.group(1):
        new = imp.group(0).replace("} from", "  type WorkLocation,\n} from") if "\n" in imp.group(1) \
              else imp.group(0).replace(" } from", ", type WorkLocation } from")
        t = t.replace(imp.group(0), new)

    # 5. FormControl / InputLabel / Select / MenuItem must be imported from MUI
    mui = re.search(r"import \{([^}]*)\} from '@mui/material';", t)
    if not mui:
        sys.exit(f"{name}: @mui/material import not found")
    missing = [c for c in ("FormControl", "InputLabel", "Select", "MenuItem") if not re.search(rf"\b{c}\b", mui.group(1))]
    if missing:
        t = t.replace(mui.group(0), mui.group(0).replace("} from", "  " + ",\n  ".join(missing) + ",\n} from"))
    p.write_text(t)
    print(f"{name}: patched")
PY

docker compose up -d --build web