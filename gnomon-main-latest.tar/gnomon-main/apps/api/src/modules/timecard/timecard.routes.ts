import { StartTimecardRequestSchema } from '@gnomon/shared';
import { Router, type Request } from 'express';
import { z } from 'zod';

import { requireAuth, requirePermission } from '../../middleware/auth.js';
import { getAttendanceSignals } from '../attendance/attendance.service.js';
import { reconcileDailyTimecard } from '../reconciliation/reconciliation.service.js';
import {
  getTodayTimecard,
  listOverviewShifts,
  startTimecard,
  stopTimecard,
} from './timecard.service.js';

function getClientMetadata(request: Request) {
  return {
    ipAddress: request.ip || request.socket.remoteAddress || 'unknown',
    userAgent: (request.get('user-agent') ?? 'unknown').slice(0, 1_024),
  };
}

const OverviewShiftsQuerySchema = z.object({
  date: z.string().date().optional(),
});

export const timecardRouter = Router();

timecardRouter.use(requireAuth);

async function withAttendanceSignals(
  timecard: Awaited<ReturnType<typeof getTodayTimecard>>,
  employeeId: string,
) {
  return {
    timecard,
    signals: await getAttendanceSignals(employeeId, timecard.workDate),
    reconciliation: await reconcileDailyTimecard(employeeId, timecard.workDate),
  };
}

timecardRouter.get(
  '/today',
  requirePermission('attendance:self:read'),
  async (request, response) => {
    const timecard = await getTodayTimecard(request.authUser!.employeeId);
    response.json(await withAttendanceSignals(timecard, request.authUser!.employeeId));
  },
);

timecardRouter.get('/overview-shifts', async (request, response) => {
  const { date } = OverviewShiftsQuerySchema.parse(request.query);
  response.json(await listOverviewShifts(request.authUser!, date));
});

timecardRouter.post(
  '/start',
  requirePermission('attendance:self:write'),
  async (request, response) => {
    const { shiftCode, location } = StartTimecardRequestSchema.parse(request.body);
    const timecard = await startTimecard(
      request.authUser!.employeeId,
      shiftCode,
      location,
      getClientMetadata(request),
    );
    response.status(201).json(await withAttendanceSignals(timecard, request.authUser!.employeeId));
  },
);

timecardRouter.post(
  '/stop',
  requirePermission('attendance:self:write'),
  async (request, response) => {
    const timecard = await stopTimecard(
      request.authUser!.employeeId,
      request.authUser!.id,
      getClientMetadata(request),
    );
    response.json(await withAttendanceSignals(timecard, request.authUser!.employeeId));
  },
);
