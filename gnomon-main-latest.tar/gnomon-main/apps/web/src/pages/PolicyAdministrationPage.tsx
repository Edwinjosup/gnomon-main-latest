import type {
  LeaveBalanceAdministrationDto,
  LeaveType,
  UpdateLeaveBalanceRequest,
} from '@gnomon/shared';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import { CalendarDays, Check, Gauge, Search, Settings2, Trash2 } from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';

import { useAuth } from '../lib/auth';
import { readFormDraft, useSessionFormDraft } from '../lib/form-drafts';
import { useEmployeeLeaveBalanceAdministration, useHolidayAdministration } from '../lib/policies';
import { useUnsavedChanges } from '../lib/unsaved-changes';
import { leaveTypeLabels } from './LeavePage';

function defaultHolidayDate(): string {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() + 30);
  return date.toISOString().slice(0, 10);
}

interface HolidayFormDraft {
  date: string;
  name: string;
}

function isHolidayFormDraft(value: unknown): value is HolidayFormDraft {
  if (!value || typeof value !== 'object') return false;
  const draft = value as Partial<HolidayFormDraft>;
  return typeof draft.date === 'string' && typeof draft.name === 'string';
}

interface BalanceFormDraft {
  entitledDays: number;
  adjustedDays: number;
  note: string;
}

function isBalanceFormDraft(value: unknown): value is BalanceFormDraft {
  if (!value || typeof value !== 'object') return false;
  const draft = value as Partial<BalanceFormDraft>;
  return (
    typeof draft.entitledDays === 'number' &&
    typeof draft.adjustedDays === 'number' &&
    typeof draft.note === 'string'
  );
}

export function PolicyAdministrationPage() {
  const { user } = useAuth();
  const initialHolidayDate = useMemo(defaultHolidayDate, []);
  const holidayDraftKey = `${user?.employeeId ?? 'anonymous'}:company-holiday`;
  const recoveredHoliday = useMemo(
    () => readFormDraft(holidayDraftKey, isHolidayFormDraft),
    [holidayDraftKey],
  );
  const [year, setYear] = useState(() =>
    Number((recoveredHoliday?.date ?? initialHolidayDate).slice(0, 4)),
  );
  const holidays = useHolidayAdministration(year);
  const [holidayDate, setHolidayDate] = useState(recoveredHoliday?.date ?? initialHolidayDate);
  const [holidayName, setHolidayName] = useState(recoveredHoliday?.name ?? '');
  const [employeeCode, setEmployeeCode] = useState('');
  const [searchedEmployeeCode, setSearchedEmployeeCode] = useState('');
  const balances = useEmployeeLeaveBalanceAdministration(searchedEmployeeCode, year);
  const canUsePage = holidays.canManage || balances.canManage;
  const holidayDirty = holidayDate !== initialHolidayDate || Boolean(holidayName);
  const holidayDraft = useMemo(
    () => ({ date: holidayDate, name: holidayName }),
    [holidayDate, holidayName],
  );
  const clearHolidayDraft = useSessionFormDraft(holidayDraftKey, holidayDraft, holidayDirty);
  useUnsavedChanges(holidayDirty);

  const saveHoliday = async (event: FormEvent) => {
    event.preventDefault();
    try {
      await holidays.upsert({
        date: holidayDate,
        name: holidayName,
      });
      clearHolidayDraft();
      setHolidayDate(initialHolidayDate);
      setHolidayName('');
    } catch {
      // The mutation error is rendered by the hook.
    }
  };

  return (
    <Stack spacing={2.5}>
      <Box>
        <Typography
          sx={{ color: 'primary.dark', fontSize: 11, fontWeight: 800, letterSpacing: 1.3 }}
        >
          LEAVE & CALENDAR POLICY
        </Typography>
        <Typography variant="h4" sx={{ mt: 0.5, fontWeight: 850, letterSpacing: '-0.035em' }}>
          Leave & holidays
        </Typography>
        <Typography sx={{ maxWidth: 780, color: 'text.secondary', fontSize: 13.5, mt: 0.7 }}>
          Configure one company holiday calendar and annual employee leave entitlements.
        </Typography>
      </Box>

      {!canUsePage && <Alert severity="warning">No leave-policy administration permission.</Alert>}
      {holidays.error && <Alert severity="error">{holidays.error.message}</Alert>}
      {balances.error && <Alert severity="error">{balances.error.message}</Alert>}

      <TextField
        type="number"
        label="Policy year"
        value={year}
        onChange={(event) => {
          const nextYear = Number(event.target.value);
          if (nextYear >= 2000 && nextYear <= 2200) setYear(nextYear);
        }}
        slotProps={{ htmlInput: { min: 2000, max: 2200 } }}
        sx={{ width: { xs: '100%', sm: 180 } }}
      />

      {holidays.canManage && (
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: { xs: '1fr', lg: 'minmax(320px, .72fr) minmax(0, 1.28fr)' },
            gap: 2.5,
            alignItems: 'start',
          }}
        >
          <Card sx={{ boxShadow: 'none' }}>
            <CardContent
              component="form"
              onSubmit={(event) => void saveHoliday(event)}
              sx={{ p: 3 }}
            >
              <Stack direction="row" sx={{ alignItems: 'center', gap: 1, mb: 2.5 }}>
                <CalendarDays size={19} color="#137f8d" />
                <Box>
                  <Typography sx={{ fontSize: 15, fontWeight: 800 }}>Holiday policy</Typography>
                  <Typography sx={{ color: 'text.secondary', fontSize: 11 }}>
                    Company-wide for every employee
                  </Typography>
                </Box>
              </Stack>
              <Stack spacing={2}>
                <TextField
                  type="date"
                  label="Holiday date"
                  value={holidayDate}
                  onChange={(event) => {
                    setHolidayDate(event.target.value);
                    const selectedYear = Number(event.target.value.slice(0, 4));
                    if (selectedYear >= 2000 && selectedYear <= 2200) setYear(selectedYear);
                  }}
                  slotProps={{ inputLabel: { shrink: true } }}
                  required
                />
                <TextField
                  label="Holiday name"
                  value={holidayName}
                  onChange={(event) => setHolidayName(event.target.value)}
                  slotProps={{ htmlInput: { maxLength: 120 } }}
                  required
                />
                <Button
                  type="submit"
                  variant="contained"
                  disabled={holidayName.trim().length < 2 || holidays.isUpdating}
                  startIcon={
                    holidays.isUpdating ? <CircularProgress size={15} /> : <Check size={16} />
                  }
                >
                  Save holiday
                </Button>
              </Stack>
            </CardContent>
          </Card>
          <HolidayList
            holidays={holidays.holidays}
            loading={holidays.isLoading}
            updating={holidays.isUpdating}
            onArchive={(holidayId) => void holidays.archive(holidayId).catch(() => undefined)}
          />
        </Box>
      )}

      {balances.canManage && (
        <Card sx={{ boxShadow: 'none' }}>
          <CardContent sx={{ p: { xs: 2.5, md: 3 } }}>
            <Stack
              direction={{ xs: 'column', md: 'row' }}
              sx={{ justifyContent: 'space-between', alignItems: { md: 'center' }, gap: 2 }}
            >
              <Stack direction="row" sx={{ alignItems: 'center', gap: 1.2 }}>
                <Gauge size={19} color="#137f8d" />
                <Box>
                  <Typography sx={{ fontSize: 15, fontWeight: 800 }}>
                    Employee leave balances
                  </Typography>
                  <Typography sx={{ color: 'text.secondary', fontSize: 11.5 }}>
                    Paid entitlements by employee and calendar year
                  </Typography>
                </Box>
              </Stack>
              <Stack
                component="form"
                direction={{ xs: 'column', sm: 'row' }}
                sx={{ gap: 1 }}
                onSubmit={(event) => {
                  event.preventDefault();
                  setSearchedEmployeeCode(employeeCode.trim().toUpperCase());
                }}
              >
                <TextField
                  size="small"
                  label="Employee code"
                  value={employeeCode}
                  onChange={(event) => setEmployeeCode(event.target.value.toUpperCase())}
                  slotProps={{ htmlInput: { maxLength: 50 } }}
                  required
                />
                <Button type="submit" variant="outlined" startIcon={<Search size={15} />}>
                  Load balances
                </Button>
              </Stack>
            </Stack>

            {balances.isLoading ? (
              <Box sx={{ py: 8, textAlign: 'center' }}>
                <CircularProgress size={25} />
              </Box>
            ) : balances.employee ? (
              <Box sx={{ mt: 2.5 }}>
                <Stack direction="row" sx={{ alignItems: 'center', gap: 0.75, mb: 1.5 }}>
                  <Typography sx={{ fontSize: 13.5, fontWeight: 820 }}>
                    {balances.employee.employeeDisplayName}
                  </Typography>
                  <Chip size="small" label={balances.employee.employeeCode} variant="outlined" />
                </Stack>
                <Box
                  sx={{
                    display: 'grid',
                    gridTemplateColumns: { xs: '1fr', xl: 'repeat(3, minmax(0, 1fr))' },
                    gap: 1.5,
                  }}
                >
                  {balances.employee.balances.map((balance) => (
                    <BalanceEditor
                      key={balance.leaveType}
                      balance={balance}
                      draftKey={`${user?.employeeId ?? 'anonymous'}:${balances.employee!.employeeId}:${year}:${balance.leaveType}:leave-balance`}
                      disabled={balances.isUpdating}
                      onSave={(input) => balances.update(input)}
                    />
                  ))}
                </Box>
              </Box>
            ) : (
              <Box
                sx={{
                  minHeight: 160,
                  mt: 2.5,
                  display: 'grid',
                  placeItems: 'center',
                  textAlign: 'center',
                  border: '1px dashed',
                  borderColor: 'divider',
                  borderRadius: 2.5,
                }}
              >
                <Box>
                  <Settings2 size={24} color="#8b97a8" />
                  <Typography sx={{ mt: 0.6, color: 'text.secondary', fontSize: 12 }}>
                    Enter an employee code to configure paid leave.
                  </Typography>
                </Box>
              </Box>
            )}
          </CardContent>
        </Card>
      )}
    </Stack>
  );
}

function HolidayList({
  holidays,
  loading,
  updating,
  onArchive,
}: {
  holidays: ReturnType<typeof useHolidayAdministration>['holidays'];
  loading: boolean;
  updating: boolean;
  onArchive: (holidayId: string) => void;
}) {
  const active = holidays.filter(
    (holiday) => holiday.status === 'active' && holiday.scopeType === 'company',
  );
  return (
    <Card sx={{ boxShadow: 'none' }}>
      <CardContent sx={{ p: 3 }}>
        <Typography sx={{ fontSize: 15, fontWeight: 800 }}>Holiday calendar</Typography>
        <Typography sx={{ color: 'text.secondary', fontSize: 11.5 }}>
          Active company dates for the selected year
        </Typography>
        {loading ? (
          <Box sx={{ py: 8, textAlign: 'center' }}>
            <CircularProgress size={24} />
          </Box>
        ) : active.length ? (
          <Stack spacing={1} sx={{ mt: 2 }}>
            {active.map((holiday) => (
              <Stack
                key={holiday.id}
                direction="row"
                sx={{
                  alignItems: 'center',
                  gap: 1.25,
                  p: 1.4,
                  borderRadius: 2,
                  bgcolor: '#f7f9fb',
                }}
              >
                <Box
                  sx={{
                    minWidth: 48,
                    px: 0.8,
                    py: 0.6,
                    textAlign: 'center',
                    borderRadius: 1.5,
                    bgcolor: '#f1edff',
                    color: '#6852a8',
                  }}
                >
                  <Typography sx={{ fontSize: 10, fontWeight: 850 }}>
                    {new Date(`${holiday.date}T00:00:00Z`).toLocaleDateString('en-IN', {
                      day: '2-digit',
                      month: 'short',
                      timeZone: 'UTC',
                    })}
                  </Typography>
                </Box>
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Typography noWrap sx={{ fontSize: 12.5, fontWeight: 780 }}>
                    {holiday.name}
                  </Typography>
                  <Typography sx={{ color: 'text.secondary', fontSize: 10.5 }}>
                    Company-wide
                  </Typography>
                </Box>
                <Button
                  color="error"
                  aria-label={`Archive ${holiday.name}`}
                  disabled={updating}
                  onClick={() => onArchive(holiday.id)}
                  sx={{ minWidth: 38, px: 0.8 }}
                >
                  <Trash2 size={15} />
                </Button>
              </Stack>
            ))}
          </Stack>
        ) : (
          <Typography sx={{ py: 7, textAlign: 'center', color: 'text.secondary', fontSize: 12 }}>
            No company holidays configured for this year.
          </Typography>
        )}
      </CardContent>
    </Card>
  );
}

function BalanceEditor({
  balance,
  draftKey,
  disabled,
  onSave,
}: {
  balance: LeaveBalanceAdministrationDto;
  draftKey: string;
  disabled: boolean;
  onSave: (input: UpdateLeaveBalanceRequest) => Promise<unknown>;
}) {
  const recoveredDraft = useMemo(() => readFormDraft(draftKey, isBalanceFormDraft), [draftKey]);
  const preserveRecovered = useRef(Boolean(recoveredDraft));
  const [entitledDays, setEntitledDays] = useState(
    recoveredDraft?.entitledDays ?? balance.entitledDays,
  );
  const [adjustedDays, setAdjustedDays] = useState(
    recoveredDraft?.adjustedDays ?? balance.adjustedDays,
  );
  const [note, setNote] = useState(recoveredDraft?.note ?? balance.note);
  const [savedValues, setSavedValues] = useState<BalanceFormDraft>({
    entitledDays: balance.entitledDays,
    adjustedDays: balance.adjustedDays,
    note: balance.note,
  });
  const label = useMemo(() => leaveTypeLabels[balance.leaveType as LeaveType], [balance.leaveType]);
  const isDirty =
    entitledDays !== savedValues.entitledDays ||
    adjustedDays !== savedValues.adjustedDays ||
    note !== savedValues.note;
  const draft = useMemo(
    () => ({ entitledDays, adjustedDays, note }),
    [adjustedDays, entitledDays, note],
  );
  const clearDraft = useSessionFormDraft(draftKey, draft, isDirty);
  useUnsavedChanges(isDirty);

  useEffect(() => {
    if (preserveRecovered.current) {
      preserveRecovered.current = false;
      return;
    }
    setEntitledDays(balance.entitledDays);
    setAdjustedDays(balance.adjustedDays);
    setNote(balance.note);
    setSavedValues({
      entitledDays: balance.entitledDays,
      adjustedDays: balance.adjustedDays,
      note: balance.note,
    });
  }, [balance]);

  const save = async () => {
    await onSave({
      leaveType: balance.leaveType,
      year: balance.year,
      entitledDays,
      adjustedDays,
      note,
    });
    setSavedValues({ entitledDays, adjustedDays, note });
    clearDraft();
  };

  return (
    <Box sx={{ p: 2, border: '1px solid', borderColor: 'divider', borderRadius: 2.5 }}>
      <Stack direction="row" sx={{ justifyContent: 'space-between', gap: 1, mb: 1.5 }}>
        <Box>
          <Typography sx={{ fontSize: 13, fontWeight: 820 }}>{label}</Typography>
          <Typography sx={{ color: 'text.secondary', fontSize: 10.5 }}>
            {balance.pendingDays} pending · {balance.approvedDays} approved
          </Typography>
        </Box>
        <Chip
          size="small"
          color={balance.configured ? 'success' : 'default'}
          label={balance.configured ? `${balance.availableDays} available` : 'Not set'}
        />
      </Stack>
      <Stack spacing={1.25}>
        <Stack direction="row" spacing={1}>
          <TextField
            fullWidth
            size="small"
            type="number"
            label={`${label} entitlement`}
            value={entitledDays}
            onChange={(event) => setEntitledDays(Number(event.target.value))}
            slotProps={{ htmlInput: { min: 0, max: 365, step: 0.5 } }}
          />
          <TextField
            fullWidth
            size="small"
            type="number"
            label={`${label} adjustment`}
            value={adjustedDays}
            onChange={(event) => setAdjustedDays(Number(event.target.value))}
            slotProps={{ htmlInput: { min: -365, max: 365, step: 0.5 } }}
          />
        </Stack>
        <TextField
          size="small"
          label={`${label} note`}
          value={note}
          onChange={(event) => setNote(event.target.value)}
          slotProps={{ htmlInput: { maxLength: 500 } }}
        />
        <Button
          variant="outlined"
          disabled={
            disabled || entitledDays + adjustedDays < balance.pendingDays + balance.approvedDays
          }
          onClick={() => void save().catch(() => undefined)}
        >
          Save {label.toLowerCase()}
        </Button>
      </Stack>
    </Box>
  );
}
