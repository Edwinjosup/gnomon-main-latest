import 'dotenv/config';

import { z } from 'zod';

const booleanString = z
  .enum(['true', 'false'])
  .default('false')
  .transform((value) => value === 'true');

const EnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(4000),
  MONGODB_URI: z.string().min(1).default('mongodb://localhost:27017/gnomon'),
  WEB_ORIGIN: z.string().url().default('http://localhost:5173'),
  ACCESS_TOKEN_SECRET: z.string().min(32),
  REFRESH_TOKEN_SECRET: z.string().min(32),
  ACCESS_TOKEN_TTL: z.string().default('15m'),
  REFRESH_TOKEN_TTL: z.string().default('7d'),
  REFRESH_COOKIE_MAX_AGE_MS: z.coerce.number().int().positive().default(604_800_000),
  COOKIE_SECURE: booleanString,

  // LDAP / Active Directory Configuration
  LDAP_ENABLED: booleanString,
  LDAP_URL: z.string().default('ldap://127.0.0.1:389'),
  LDAP_BIND_DN: z.string().default(''),
  LDAP_BIND_PASSWORD: z.string().default(''),
  LDAP_BASE_DN: z.string().default(''),
  LDAP_SEARCH_FILTER: z
    .string()
    .default('(&(objectCategory=person)(objectClass=user)(|(sAMAccountName={{username}})(mail={{username}})))'),
});

const result = EnvSchema.safeParse(process.env);

if (!result.success) {
  const details = result.error.issues
    .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
    .join(', ');
  throw new Error(`Invalid environment configuration: ${details}`);
}

export const env = result.data;
