import {
  SHIFT_TEMPLATES,
  type DailyReconciliationDto,
  type ReconciliationAnomaly,
  type ShiftCode,
  type WorkLocation,
} from '@gnomon/shared';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  FormControl,
  InputLabel,
  LinearProgress,
  MenuItem,
  Select,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import {
  AlertTriangle,
  ArrowUpRight,
  CalendarDays,
  CheckCircle2,
  Clock3,
  CreditCard,
  FileClock,
  Fingerprint,
  MonitorCheck,
  ShieldCheck,
  Sparkles,
  Users,
} from 'lucide-react';
import { useState } from 'react';

import { useAuth } from '../lib/auth';
import {
  formatElapsed,
  formatIndiaTime,
  useOverviewShifts,
  useTodayTimecard,
} from '../lib/timecard';
import type { AppView } from '../navigation';

interface DashboardPageProps {
  onNavigate: (view: AppView) => void;
}

function getGreeting(): string {
  const hour = Number(
    new Intl.DateTimeFormat('en-IN', {
      hour: '2-digit',
      hourCycle: 'h23',
      timeZone: 'Asia/Kolkata',
    }).format(new Date()),
  );
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

const policyItems = [
  { label: 'Morning (M) buffer', value: '06:00 – 08:00' },
  { label: 'Regular (R) buffer', value: '08:00 – 10:00' },
  { label: 'Afternoon (A) buffer', value: '13:00 – 15:00' },
  { label: 'Night (N) buffer', value: '15:00 – 00:00' },
  { label: 'Required hours', value: '9h 00m' },
  { label: 'Workday boundary', value: '07:00 – 07:00' },
];

const anomalyLabels: Record<ReconciliationAnomaly, string> = {
  missing_biometric_in: 'Missing biometric in',
  missing_biometric_out: 'Missing biometric out',
  missing_access_entry: 'Missing card entry',
  missing_access_exit: 'Missing card exit',
  missing_web_start: 'Missing website start',
  missing_web_stop: 'Missing website stop',
  source_time_mismatch: 'Source times differ',
  insufficient_hours: 'Below nine hours',
  show_time_outside_web_session: 'Show time outside website session',
  show_time_exceeds_presence: 'Show time exceeds presence',
  invalid_event_order: 'Invalid event order',
};

function formatMinutesCompact(minutes: number): string {
  const hours = Math.floor(Math.abs(minutes) / 60);
  const remainder = Math.abs(minutes) % 60;
  return `${hours}h ${String(remainder).padStart(2, '0')}m`;
}

export function DashboardPage({ onNavigate }: DashboardPageProps) {
  const { user } = useAuth();
  const timecard = useTodayTimecard();
  const overviewShifts = useOverviewShifts();
  const [selectedShift, setSelectedShift] = useState<ShiftCode | ''>('');
  const [location, setLocation] = useState<WorkLocation>('WFO');

  const firstName = user?.displayName.split(' ')[0] ?? 'there';
  const today = new Intl.DateTimeFormat('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'Asia/Kolkata',
  }).format(new Date());
  const completion = Math.min(100, (timecard.trackedSeconds / (9 * 3_600)) * 100);
  const activeShift = timecard.timecard?.activeSession?.shiftCode
    ? SHIFT_TEMPLATES[timecard.timecard.activeSession.shiftCode]
    : null;

  const nextActions = [
    { view: 'timesheets' as const, label: 'Show time entries', icon: FileClock },
    ...(user?.permissions.includes('regularisation:create')
      ? [
          {
            view: 'regularisation' as const,
            label: 'Attendance correction',
            icon: Fingerprint,
          },
        ]
      : []),
    ...(user?.permissions.includes('leave:create')
      ? [{ view: 'leave' as const, label: 'Leave requests', icon: CalendarDays }]
      : []),
    ...(user?.permissions.some(
      (permission) => permission === 'regularisation:approve' || permission === 'leave:approve',
    )
      ? [{ view: 'approvals' as const, label: 'Manager approvals', icon: ShieldCheck }]
      : []),
  ];

  const biometric = timecard.signals?.biometric;
  const accessCard = timecard.signals?.accessCard;

  const sourceSignals = [
    {
      label: 'Biometric',
      detail: biometric?.eventCount
        ? `${biometric.eventCount} event${biometric.eventCount === 1 ? '' : 's'} · ${formatIndiaTime(biometric.firstEventAt)} – ${formatIndiaTime(biometric.lastEventAt)}`
        : 'Awaiting attendance import',
      icon: Fingerprint,
      tone: '#6d5bd0',
      background: '#f2efff',
      status:
        biometric?.status === 'complete'
          ? 'Complete'
          : biometric?.status === 'incomplete'
            ? 'Needs review'
            : 'Pending source',
    },
    {
      label: 'Access card',
      detail: accessCard?.eventCount
        ? `${accessCard.eventCount} event${accessCard.eventCount === 1 ? '' : 's'} · ${formatIndiaTime(accessCard.firstEventAt)} – ${formatIndiaTime(accessCard.lastEventAt)}`
        : 'Awaiting access-card import',
      icon: CreditCard,
      tone: '#d06f21',
      background: '#fff3e8',
      status:
        accessCard?.status === 'complete'
          ? 'Complete'
          : accessCard?.status === 'incomplete'
            ? 'Needs review'
            : 'Pending source',
    },
    {
      label: 'Website',
      detail: timecard.timecard?.activeSession
        ? `Started ${formatIndiaTime(timecard.timecard.activeSession.startedAt)}${activeShift ? ` · ${activeShift.code} (${activeShift.label})` : ''}`
        : timecard.timecard?.sessions.length
          ? `${timecard.timecard.sessions.length} session${timecard.timecard.sessions.length === 1 ? '' : 's'} recorded`
          : 'No session started',
      icon: MonitorCheck,
      tone: '#0d8b9b',
      background: '#e7f8fa',
      status: timecard.timecard?.activeSession ? 'Tracking' : 'Ready',
    },
  ];

  const canViewShiftOverview =
    (user?.permissions.some(
      (permission) =>
        permission === 'attendance:team:read' || permission === 'attendance:all:read',
    ) ?? false) &&
    (overviewShifts.isLoading || Boolean(overviewShifts.data?.visible));

  return (
    <Stack spacing={3.25} sx={{ width: '100%', maxWidth: 1440, mx: 'auto' }}>
      <Box
        sx={{
          position: 'relative',
          overflow: 'hidden',
          px: { xs: 2.5, sm: 3.25 },
          py: { xs: 2.5, sm: 2.75 },
          border: '1px solid rgba(214,225,232,.95)',
          borderRadius: '22px',
          background:
            'radial-gradient(circle at 88% 0%, rgba(32,190,202,.12), transparent 27%), linear-gradient(135deg, rgba(255,255,255,.98), rgba(246,251,252,.94))',
          boxShadow: '0 14px 36px rgba(20,32,51,.055)',
          '&::after': {
            content: '""',
            position: 'absolute',
            width: 150,
            height: 150,
            right: -80,
            bottom: -105,
            borderRadius: '50%',
            border: '18px solid rgba(19,151,163,.045)',
          },
        }}
      >
        <Stack
          direction={{ xs: 'column', sm: 'row' }}
          sx={{
            position: 'relative',
            zIndex: 1,
            justifyContent: 'space-between',
            alignItems: { sm: 'center' },
            gap: 1.5,
          }}
        >
          <Box>
            <Typography
              sx={{
                color: 'primary.dark',
                fontSize: 11,
                fontWeight: 800,
                mb: 0.65,
                letterSpacing: 0.5,
              }}
            >
              {today.toUpperCase()}
            </Typography>
            <Typography variant="h4" sx={{ fontWeight: 850, letterSpacing: '-0.04em' }}>
              {getGreeting()}, {firstName}
            </Typography>
            <Typography sx={{ mt: 0.65, color: 'text.secondary', fontSize: 14 }}>
              Here is your workday across attendance, time and approvals.
            </Typography>
          </Box>
          <Chip
            icon={<ShieldCheck size={15} />}
            label={`${user?.permissions.length ?? 0} active permissions`}
            variant="outlined"
            sx={{
              alignSelf: { xs: 'flex-start', sm: 'auto' },
              height: 34,
              bgcolor: 'rgba(255,255,255,.86)',
              borderColor: 'rgba(18,148,161,.2)',
            }}
          />
        </Stack>
      </Box>

      {(!timecard.canRead || !timecard.canWrite) && (
        <Alert severity="warning">
          Your account needs Employee attendance permissions before it can use the website timecard.
        </Alert>
      )}
      {timecard.error && <Alert severity="error">{timecard.error.message}</Alert>}

      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', lg: 'minmax(0, 1.45fr) minmax(310px, .75fr)' },
          gap: 2.5,
        }}
      >
        <Card
          sx={{
            overflow: 'hidden',
            border: 0,
            color: '#fff',
            background:
              'radial-gradient(circle at 88% 16%, rgba(56,218,227,.22), transparent 34%), linear-gradient(135deg, #101a2d 0%, #0a1220 70%)',
            boxShadow: '0 18px 48px rgba(12,18,32,.16)',
          }}
        >
          <CardContent sx={{ p: { xs: 2.75, sm: 4 } }}>
            <Stack
              direction={{ xs: 'column', sm: 'row' }}
              sx={{ justifyContent: 'space-between', gap: 3 }}
            >
              <Box>
                <Stack direction="row" sx={{ alignItems: 'center', gap: 1, mb: 2.5, flexWrap: 'wrap' }}>
                  <Box
                    sx={{
                      width: 34,
                      height: 34,
                      borderRadius: 2,
                      display: 'grid',
                      placeItems: 'center',
                      bgcolor: 'rgba(47,208,220,.14)',
                    }}
                  >
                    <Clock3 size={18} color="#47d4df" />
                  </Box>
                  <Box>
                    <Typography sx={{ fontSize: 12, color: 'rgba(255,255,255,.58)' }}>
                      Website timecard
                    </Typography>
                    <Typography sx={{ fontSize: 14, fontWeight: 750 }}>
                      {timecard.timecard?.activeSession
                        ? 'Your day is in progress'
                        : 'Ready when you are'}
                    </Typography>
                  </Box>
                  {activeShift && (
                    <Chip
                      size="small"
                      label={`${activeShift.code} · ${activeShift.label} (${activeShift.bufferLabel})`}
                      sx={{
                        ml: { sm: 1 },
                        fontWeight: 750,
                        bgcolor: 'rgba(55,203,215,.18)',
                        color: '#67e8f9',
                      }}
                    />
                  )}
                </Stack>

                <Typography
                  sx={{
                    fontSize: { xs: 42, sm: 58 },
                    lineHeight: 1,
                    fontWeight: 850,
                    letterSpacing: '-0.055em',
                    fontVariantNumeric: 'tabular-nums',
                  }}
                >
                  {timecard.isLoading ? '— — : — —' : formatElapsed(timecard.trackedSeconds)}
                </Typography>
                <Typography sx={{ mt: 1, color: 'rgba(255,255,255,.5)', fontSize: 12.5 }}>
                  Tracked for work date {timecard.timecard?.workDate ?? '—'}
                </Typography>
              </Box>

              <Stack sx={{ minWidth: { sm: 255 }, justifyContent: 'space-between', gap: 2 }}>
                <Box>
                  <Stack direction="row" sx={{ justifyContent: 'space-between', mb: 1 }}>
                    <Typography sx={{ fontSize: 11, color: 'rgba(255,255,255,.5)' }}>
                      9-hour completion
                    </Typography>
                    <Typography sx={{ fontSize: 11, fontWeight: 750 }}>
                      {Math.round(completion)}%
                    </Typography>
                  </Stack>
                  <LinearProgress
                    variant="determinate"
                    value={completion}
                    sx={{
                      height: 6,
                      borderRadius: 4,
                      bgcolor: 'rgba(255,255,255,.1)',
                      '& .MuiLinearProgress-bar': { bgcolor: '#3cd3df', borderRadius: 4 },
                    }}
                  />
                </Box>

                {!timecard.timecard?.activeSession && (
                  <FormControl size="small" fullWidth>
                    <InputLabel
                      id="dashboard-shift-select-label"
                      sx={{
                        color: 'rgba(255,255,255,.7)',
                        '&.Mui-focused': { color: '#37cbd7' },
                      }}
                    >
                      Select shift template
                    </InputLabel>
                    <Select
                      labelId="dashboard-shift-select-label"
                      value={selectedShift}
                      label="Select shift template"
                      disabled={!timecard.canWrite || timecard.isLoading || timecard.isUpdating}
                      onChange={(event) => setSelectedShift(event.target.value as ShiftCode)}
                      sx={{
                        color: '#fff',
                        bgcolor: 'rgba(255,255,255,.06)',
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: 'rgba(255,255,255,.24)',
                        },
                        '&:hover .MuiOutlinedInput-notchedOutline': {
                          borderColor: '#37cbd7',
                        },
                        '& .MuiSvgIcon-root': { color: '#fff' },
                      }}
                    >
                      {Object.values(SHIFT_TEMPLATES).map((shift) => (
                        <MenuItem key={shift.code} value={shift.code}>
                          {shift.code} — {shift.label}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                )}

                {!timecard.timecard?.activeSession && (
  <FormControl
    size="small"
    sx={{ minWidth: 150, display: 'flex', width: { xs: '100%', sm: 'auto' }, mt: 1.5, mb: 0.5 }}
  >
    <InputLabel id="DashboardPage-location-label">Work location</InputLabel>
    <Select
      labelId="DashboardPage-location-label"
      value={location}
      label="Work location"
      onChange={(event) => setLocation(event.target.value as WorkLocation)}
    >
      <MenuItem value="WFO">Office (WFO)</MenuItem>
      <MenuItem value="WFH">Home (WFH)</MenuItem>
    </Select>
  </FormControl>
)}

                <Button
                  size="large"
                  variant="contained"
                  disabled={
                    !timecard.canWrite ||
                    timecard.isLoading ||
                    timecard.isUpdating ||
                    (!timecard.timecard?.activeSession && !selectedShift)
                  }
                  onClick={() => {
                    if (timecard.timecard?.activeSession) {
                      timecard.stop();
                    } else if (selectedShift) {
                      timecard.start(selectedShift, location);
                    }
                  }}
                  startIcon={
                    timecard.isUpdating ? (
                      <CircularProgress size={16} color="inherit" />
                    ) : timecard.timecard?.activeSession ? (
                      <CheckCircle2 size={18} />
                    ) : (
                      <Sparkles size={18} />
                    )
                  }
                  sx={{
                    py: 1.25,
                    bgcolor: timecard.timecard?.activeSession ? '#e05e62' : '#37cbd7',
                    color: timecard.timecard?.activeSession ? '#fff' : '#07151a',
                    boxShadow: 'none',
                    '&:hover': {
                      bgcolor: timecard.timecard?.activeSession ? '#c8494d' : '#54d9e2',
                      boxShadow: 'none',
                    },
                    '&.Mui-disabled': {
                      bgcolor: 'rgba(255,255,255,.14)',
                      color: 'rgba(255,255,255,.45)',
                    },
                  }}
                >
                  {timecard.isUpdating
                    ? 'Updating…'
                    : timecard.timecard?.activeSession
                      ? 'Stop workday'
                      : timecard.timecard?.state === 'completed'
                        ? 'Start another session'
                        : 'Start workday'}
                </Button>
              </Stack>
            </Stack>
          </CardContent>
        </Card>

        <Card>
          <CardContent sx={{ p: 3 }}>
            <Stack direction="row" sx={{ alignItems: 'center', justifyContent: 'space-between' }}>
              <Box>
                <Typography sx={{ fontSize: 15, fontWeight: 800 }}>Today’s policy</Typography>
                <Typography sx={{ color: 'text.secondary', fontSize: 11.5, mt: 0.25 }}>
                  Asia/Kolkata shift buffers
                </Typography>
              </Box>
              <Box
                sx={{
                  width: 34,
                  height: 34,
                  borderRadius: 2,
                  display: 'grid',
                  placeItems: 'center',
                  bgcolor: '#eef7f8',
                  color: '#117f8c',
                }}
              >
                <CalendarDays size={17} />
              </Box>
            </Stack>
            <Stack sx={{ mt: 2 }} divider={<DividerLine />}>
              {policyItems.map((item) => (
                <Stack
                  key={item.label}
                  direction="row"
                  sx={{ py: 1.15, alignItems: 'center', justifyContent: 'space-between' }}
                >
                  <Typography sx={{ color: 'text.secondary', fontSize: 12.5 }}>
                    {item.label}
                  </Typography>
                  <Typography sx={{ fontSize: 12.5, fontWeight: 750 }}>{item.value}</Typography>
                </Stack>
              ))}
            </Stack>
          </CardContent>
        </Card>
      </Box>

      {canViewShiftOverview && (
        <Card sx={{ boxShadow: 'none' }}>
          <CardContent sx={{ p: { xs: 2.5, md: 3 } }}>
            <Stack
              direction={{ xs: 'column', sm: 'row' }}
              sx={{ justifyContent: 'space-between', alignItems: { sm: 'center' }, gap: 1.5, mb: 2 }}
            >
              <Stack direction="row" sx={{ alignItems: 'center', gap: 1.5 }}>
                <Box
                  sx={{
                    width: 40,
                    height: 40,
                    display: 'grid',
                    placeItems: 'center',
                    borderRadius: 2.25,
                    bgcolor: '#edf7f8',
                    color: '#117f8c',
                  }}
                >
                  <Users size={19} />
                </Box>
                <Box>
                  <Typography sx={{ fontSize: 15.5, fontWeight: 820 }}>
                    Employee shift selections
                  </Typography>
                  <Typography sx={{ color: 'text.secondary', fontSize: 11.5 }}>
                    Timecard shifts selected for work date{' '}
                    {overviewShifts.data?.workDate ?? timecard.timecard?.workDate ?? '—'}
                  </Typography>
                </Box>
              </Stack>
              <Chip
                size="small"
                variant="outlined"
                label={`${overviewShifts.data?.records.length ?? 0} record${(overviewShifts.data?.records.length ?? 0) === 1 ? '' : 's'}`}
                sx={{ fontWeight: 750 }}
              />
            </Stack>

            {overviewShifts.error && (
              <Alert severity="error" sx={{ mb: 2 }}>
                {overviewShifts.error.message}
              </Alert>
            )}

            <TableContainer sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 2 }}>
              <Table size="small">
                <TableHead sx={{ bgcolor: '#f6f8fa' }}>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 750 }}>Employee</TableCell>
                    <TableCell sx={{ fontWeight: 750 }}>Department</TableCell>
                    <TableCell sx={{ fontWeight: 750 }}>Shift</TableCell>
                    <TableCell sx={{ fontWeight: 750 }}>Buffer window</TableCell>
                    <TableCell sx={{ fontWeight: 750 }}>Started (IST)</TableCell>
                    <TableCell sx={{ fontWeight: 750 }}>Stopped (IST)</TableCell>
                    <TableCell sx={{ fontWeight: 750 }}>Status</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {overviewShifts.isLoading ? (
                    <TableRow>
                      <TableCell colSpan={7} align="center" sx={{ py: 3 }}>
                        <CircularProgress size={20} />
                      </TableCell>
                    </TableRow>
                  ) : overviewShifts.data?.records.length ? (
                    overviewShifts.data.records.map((record) => (
                      <TableRow key={record.id} hover>
                        <TableCell>
                          <Typography sx={{ fontSize: 13, fontWeight: 750 }}>
                            {record.employeeName}
                          </Typography>
                          <Typography sx={{ fontSize: 11, color: 'text.secondary' }}>
                            {record.employeeCode}
                          </Typography>
                        </TableCell>
                        <TableCell sx={{ fontSize: 12.5 }}>{record.department}</TableCell>
                        <TableCell>
                          <Chip
                            size="small"
                            color="primary"
                            variant="outlined"
                            label={`${record.shiftCode} · ${record.shiftLabel}`}
                            sx={{ fontWeight: 750 }}
                          />
                        </TableCell>
                        <TableCell sx={{ fontSize: 12.5 }}>{record.bufferLabel}</TableCell>
                        <TableCell sx={{ fontSize: 12.5 }}>
                          {formatIndiaTime(record.startedAt)}
                        </TableCell>
                        <TableCell sx={{ fontSize: 12.5 }}>
                          {formatIndiaTime(record.stoppedAt)}
                        </TableCell>
                        <TableCell>
                          <Chip
                            size="small"
                            label={record.status === 'running' ? 'Active' : record.status}
                            color={record.status === 'running' ? 'success' : 'default'}
                            variant={record.status === 'running' ? 'filled' : 'outlined'}
                            sx={{ textTransform: 'capitalize', fontSize: 11 }}
                          />
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell
                        colSpan={7}
                        align="center"
                        sx={{ py: 3, color: 'text.secondary', fontSize: 12.5 }}
                      >
                        No employee shift timecards recorded yet for today.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>
      )}

      <Box>
        <Stack
          direction="row"
          sx={{ alignItems: 'flex-end', justifyContent: 'space-between', mb: 1.5 }}
        >
          <Box>
            <Typography sx={{ fontSize: 16, fontWeight: 800 }}>Attendance signals</Typography>
            <Typography sx={{ color: 'text.secondary', fontSize: 12 }}>
              Independent sources reconciled into one attendance day.
            </Typography>
          </Box>
        </Stack>
        <Box
          sx={{
            display: 'grid',
            gridTemplateColumns: { xs: '1fr', md: 'repeat(3, 1fr)' },
            gap: 2,
          }}
        >
          {sourceSignals.map((signal) => {
            const Icon = signal.icon;
            return (
              <Card
                key={signal.label}
                sx={{
                  boxShadow: 'none',
                  transition: 'transform 160ms ease, box-shadow 160ms ease',
                  '&:hover': {
                    transform: 'translateY(-2px)',
                    boxShadow: '0 14px 30px rgba(21,39,58,.07)',
                  },
                }}
              >
                <CardContent sx={{ p: 2.5 }}>
                  <Stack direction="row" sx={{ alignItems: 'center', gap: 1.75 }}>
                    <Box
                      sx={{
                        width: 42,
                        height: 42,
                        flex: '0 0 auto',
                        borderRadius: 2.25,
                        display: 'grid',
                        placeItems: 'center',
                        bgcolor: signal.background,
                        color: signal.tone,
                      }}
                    >
                      <Icon size={20} />
                    </Box>
                    <Box sx={{ minWidth: 0, flex: 1 }}>
                      <Stack
                        direction="row"
                        sx={{ alignItems: 'center', justifyContent: 'space-between' }}
                      >
                        <Typography sx={{ fontSize: 13.5, fontWeight: 780 }}>
                          {signal.label}
                        </Typography>
                        <Typography sx={{ color: signal.tone, fontSize: 10.5, fontWeight: 750 }}>
                          {signal.status}
                        </Typography>
                      </Stack>
                      <Typography noWrap sx={{ mt: 0.35, color: 'text.secondary', fontSize: 11.5 }}>
                        {signal.detail}
                      </Typography>
                    </Box>
                  </Stack>
                </CardContent>
              </Card>
            );
          })}
        </Box>
      </Box>

      <ReconciliationCard reconciliation={timecard.reconciliation} />

      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: { xs: '1fr', lg: 'minmax(0, 1.15fr) minmax(330px, .85fr)' },
          gap: 2.5,
        }}
      >
        <Card sx={{ boxShadow: 'none' }}>
          <CardContent sx={{ p: 3 }}>
            <Stack
              direction="row"
              sx={{ justifyContent: 'space-between', alignItems: 'center', mb: 2.25 }}
            >
              <Box>
                <Typography sx={{ fontSize: 15, fontWeight: 800 }}>Website sessions</Typography>
                <Typography sx={{ color: 'text.secondary', fontSize: 11.5 }}>
                  Start and stop activity for the current work date
                </Typography>
              </Box>
              <Button
                size="small"
                endIcon={<ArrowUpRight size={15} />}
                onClick={() => onNavigate('timecard')}
              >
                View details
              </Button>
            </Stack>
            {timecard.timecard?.sessions.length ? (
              <Stack spacing={1}>
                {timecard.timecard.sessions
                  .slice(-3)
                  .reverse()
                  .map((session, index) => {
                    const sessionShift = session.shiftCode
                      ? SHIFT_TEMPLATES[session.shiftCode]
                      : null;
                    return (
                      <Stack
                        key={session.id}
                        direction="row"
                        sx={{
                          alignItems: 'center',
                          gap: 1.5,
                          px: 1.5,
                          py: 1.25,
                          borderRadius: 2,
                          bgcolor: index === 0 ? '#f5fafb' : 'transparent',
                        }}
                      >
                        <Box
                          sx={{
                            width: 8,
                            height: 8,
                            borderRadius: '50%',
                            bgcolor: session.status === 'running' ? '#25ae73' : '#9ba6b5',
                            boxShadow:
                              session.status === 'running'
                                ? '0 0 0 4px rgba(37,174,115,.12)'
                                : 'none',
                          }}
                        />
                        <Typography sx={{ minWidth: 72, fontSize: 12.5, fontWeight: 750 }}>
                          {formatIndiaTime(session.startedAt)}
                        </Typography>
                        <Typography sx={{ color: 'text.secondary', fontSize: 12 }}>
                          to {formatIndiaTime(session.stoppedAt)}
                        </Typography>
                        {sessionShift && (
                          <Chip
                            size="small"
                            variant="outlined"
                            label={`${sessionShift.code} · ${sessionShift.label}`}
                            sx={{ height: 22, fontSize: 10.5 }}
                          />
                        )}
                        <Chip
                          size="small"
                          label={
                            session.status === 'running'
                              ? 'Active'
                              : `${session.durationMinutes ?? 0} min`
                          }
                          color={session.status === 'running' ? 'success' : 'default'}
                          variant={session.status === 'running' ? 'filled' : 'outlined'}
                          sx={{ ml: 'auto', height: 24, fontSize: 10.5 }}
                        />
                      </Stack>
                    );
                  })}
              </Stack>
            ) : (
              <Box
                sx={{
                  minHeight: 126,
                  display: 'grid',
                  placeItems: 'center',
                  textAlign: 'center',
                  border: '1px dashed',
                  borderColor: 'divider',
                  borderRadius: 2.5,
                }}
              >
                <Box>
                  <Clock3 size={22} color="#8a96a8" />
                  <Typography sx={{ mt: 0.5, fontSize: 12.5, fontWeight: 700 }}>
                    No website sessions yet
                  </Typography>
                  <Typography sx={{ color: 'text.secondary', fontSize: 11.5 }}>
                    Select a shift template and start your workday to create the first session.
                  </Typography>
                </Box>
              </Box>
            )}
          </CardContent>
        </Card>

        <Card sx={{ boxShadow: 'none' }}>
          <CardContent sx={{ p: 3 }}>
            <Typography sx={{ fontSize: 15, fontWeight: 800 }}>Quick access</Typography>
            <Typography sx={{ color: 'text.secondary', fontSize: 11.5, mb: 2 }}>
              Continue into time, attendance, leave, or manager work
            </Typography>
            <Stack spacing={1}>
              {nextActions.map((item) => {
                const Icon = item.icon;
                return (
                  <Button
                    key={item.view}
                    color="inherit"
                    onClick={() => onNavigate(item.view)}
                    sx={{
                      justifyContent: 'flex-start',
                      py: 1.15,
                      px: 1.25,
                      border: '1px solid',
                      borderColor: 'divider',
                      bgcolor: '#fff',
                      transition: 'transform 150ms ease, border-color 150ms ease',
                      '&:hover': {
                        transform: 'translateX(2px)',
                        borderColor: 'rgba(18,148,161,.34)',
                        bgcolor: '#f8fcfc',
                      },
                    }}
                  >
                    <Icon size={17} />
                    <Typography
                      sx={{ ml: 1.25, flex: 1, textAlign: 'left', fontSize: 12.5, fontWeight: 700 }}
                    >
                      {item.label}
                    </Typography>
                    <ArrowUpRight size={14} color="#8b96a5" />
                  </Button>
                );
              })}
            </Stack>
          </CardContent>
        </Card>
      </Box>
    </Stack>
  );
}

function DividerLine() {
  return <Box sx={{ borderTop: '1px solid', borderColor: 'divider' }} />;
}

function ReconciliationCard({
  reconciliation,
}: {
  reconciliation: DailyReconciliationDto | undefined;
}) {
  const statusColor =
    reconciliation?.calculated.status === 'present'
      ? 'success'
      : reconciliation?.calculated.status === 'absent'
        ? 'error'
        : reconciliation?.calculated.status === 'weekend'
          ? 'info'
          : 'warning';
  const sourceLabel =
    reconciliation?.calculated.primarySource === 'access_card'
      ? 'Access card'
      : reconciliation?.calculated.primarySource === 'website'
        ? 'Website'
        : reconciliation?.calculated.primarySource === 'biometric'
          ? 'Biometric'
          : 'Awaiting evidence';
  const completion = reconciliation
    ? Math.min(
        100,
        (reconciliation.calculated.grossMinutes / reconciliation.calculated.requiredMinutes) * 100,
      )
    : 0;

  return (
    <Card sx={{ boxShadow: 'none', overflow: 'hidden' }}>
      <CardContent sx={{ p: { xs: 2.5, md: 3 } }}>
        <Stack
          direction={{ xs: 'column', sm: 'row' }}
          sx={{ justifyContent: 'space-between', alignItems: { sm: 'center' }, gap: 1.5 }}
        >
          <Stack direction="row" sx={{ alignItems: 'center', gap: 1.5 }}>
            <Box
              sx={{
                width: 40,
                height: 40,
                display: 'grid',
                placeItems: 'center',
                borderRadius: 2.25,
                bgcolor: '#edf7f8',
                color: '#117f8c',
              }}
            >
              <ShieldCheck size={19} />
            </Box>
            <Box>
              <Typography sx={{ fontSize: 15.5, fontWeight: 820 }}>Daily reconciliation</Typography>
              <Typography sx={{ color: 'text.secondary', fontSize: 11.5 }}>
                {reconciliation
                  ? `Work date ${reconciliation.workDate} · ${reconciliation.calculated.workdayClosed ? 'window closed' : 'live calculation'}`
                  : 'Calculating attendance evidence…'}
              </Typography>
            </Box>
          </Stack>
          {reconciliation && (
            <Stack direction="row" sx={{ gap: 1, flexWrap: 'wrap' }}>
              {reconciliation.calculated.provisional && (
                <Chip size="small" label="Provisional" variant="outlined" />
              )}
              <Chip
                size="small"
                color={statusColor}
                label={reconciliation.calculated.status.replaceAll('_', ' ')}
                sx={{ textTransform: 'capitalize', fontWeight: 750 }}
              />
            </Stack>
          )}
        </Stack>

        {reconciliation && (
          <>
            <Box
              sx={{
                display: 'grid',
                gridTemplateColumns: {
                  xs: 'repeat(2, minmax(0, 1fr))',
                  md: 'repeat(5, minmax(0, 1fr))',
                },
                gap: 1,
                mt: 2.5,
              }}
            >
              <ReconciliationMetric label="Primary source" value={sourceLabel} />
              <ReconciliationMetric
                label="Biometric"
                value={formatMinutesCompact(reconciliation.sourceSummary.biometric.workedMinutes)}
              />
              <ReconciliationMetric
                label="Access card"
                value={formatMinutesCompact(reconciliation.sourceSummary.accessCard.workedMinutes)}
              />
              <ReconciliationMetric
                label="Website"
                value={formatMinutesCompact(reconciliation.sourceSummary.website.workedMinutes)}
              />
              <ReconciliationMetric
                label="Show entries"
                value={formatMinutesCompact(reconciliation.sourceSummary.showEntries.totalMinutes)}
              />
            </Box>

            <Box sx={{ mt: 2.5 }}>
              <Stack direction="row" sx={{ justifyContent: 'space-between', mb: 0.8 }}>
                <Typography sx={{ color: 'text.secondary', fontSize: 11.5 }}>
                  Calculated presence ·{' '}
                  {formatMinutesCompact(reconciliation.calculated.grossMinutes)}
                  {' / '}
                  {formatMinutesCompact(reconciliation.calculated.requiredMinutes)}
                </Typography>
                <Typography
                  sx={{
                    color:
                      reconciliation.calculated.differenceMinutes >= 0
                        ? 'success.main'
                        : 'text.secondary',
                    fontSize: 11.5,
                    fontWeight: 750,
                  }}
                >
                  {reconciliation.calculated.differenceMinutes >= 0 ? '+' : '−'}
                  {formatMinutesCompact(reconciliation.calculated.differenceMinutes)}
                </Typography>
              </Stack>
              <LinearProgress
                variant="determinate"
                value={completion}
                color={
                  reconciliation.calculated.status === 'present' &&
                  !reconciliation.calculated.requiresReview
                    ? 'success'
                    : reconciliation.calculated.status === 'absent'
                      ? 'error'
                      : 'warning'
                }
                sx={{ height: 7, borderRadius: 5 }}
              />
            </Box>

            {reconciliation.calculated.anomalies.length ? (
              <Box sx={{ mt: 2.25 }}>
                <Stack direction="row" sx={{ alignItems: 'center', gap: 0.75, mb: 1 }}>
                  <AlertTriangle size={15} color="#c17424" />
                  <Typography sx={{ color: '#945719', fontSize: 11.5, fontWeight: 800 }}>
                    Evidence requiring review
                  </Typography>
                </Stack>
                <Stack direction="row" sx={{ flexWrap: 'wrap', gap: 0.75 }}>
                  {reconciliation.calculated.anomalies.map((anomaly) => (
                    <Chip
                      key={anomaly}
                      size="small"
                      color="warning"
                      variant="outlined"
                      label={anomalyLabels[anomaly]}
                    />
                  ))}
                </Stack>
              </Box>
            ) : reconciliation.calculated.primarySource === 'none' ? (
              <Alert severity="info" sx={{ mt: 2.25 }}>
                Awaiting the first attendance signal for this work date.
              </Alert>
            ) : (
              <Alert severity="success" sx={{ mt: 2.25 }}>
                Available evidence is aligned; no discrepancy has been detected.
              </Alert>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

function ReconciliationMetric({ label, value }: { label: string; value: string }) {
  return (
    <Box sx={{ p: 1.5, borderRadius: 2, bgcolor: '#f6f8fa', minWidth: 0 }}>
      <Typography sx={{ color: 'text.secondary', fontSize: 10.5 }}>{label}</Typography>
      <Typography noWrap sx={{ mt: 0.3, fontSize: 13, fontWeight: 800 }}>
        {value}
      </Typography>
    </Box>
  );
}
