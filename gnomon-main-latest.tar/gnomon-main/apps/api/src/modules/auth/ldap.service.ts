import { Client } from 'ldapts';

import { env } from '../../config/env.js';

export interface LdapUserResult {
  dn: string;
  email: string;
  username: string;
  firstName: string;
  lastName: string;
}

export class LdapService {
  public static async authenticate(identifier: string, password: string): Promise<LdapUserResult | null> {
    if (!env.LDAP_ENABLED || !env.LDAP_URL || !env.LDAP_BIND_DN) {
      return null;
    }

    const client = new Client({
      url: env.LDAP_URL,
      timeout: 5000,
      connectTimeout: 5000,
    });

    try {
      // 1. Technical service bind
      await client.bind(env.LDAP_BIND_DN, env.LDAP_BIND_PASSWORD);

      const usernameClean = identifier.includes('@') ? identifier.split('@')[0] : identifier;
      const filter = env.LDAP_SEARCH_FILTER
        .replace(/\{\{username\}\}/g, usernameClean)
        .replace(/\{\{email\}\}/g, identifier);

      const { searchEntries } = await client.search(env.LDAP_BASE_DN, {
        scope: 'sub',
        filter,
        attributes: ['dn', 'mail', 'sAMAccountName', 'givenName', 'sn', 'displayName', 'cn'],
      });

      if (!searchEntries || searchEntries.length === 0) {
        console.warn(`[LDAP] User search found no records for: ${identifier}`);
        await client.unbind();
        return null;
      }

      const entry = searchEntries[0];
      const userDn = entry.dn;

      // 2. Unbind technical service account
      await client.unbind();

      // 3. Bind target user with their credentials
      const userClient = new Client({ url: env.LDAP_URL, timeout: 5000 });
      await userClient.bind(userDn, password);
      await userClient.unbind();

      const mail = typeof entry.mail === 'string' && entry.mail.length > 0
        ? entry.mail.toLowerCase()
        : identifier.includes('@')
          ? identifier.toLowerCase()
          : `${usernameClean.toLowerCase()}@domain.local`;

      const username = typeof entry.sAMAccountName === 'string'
        ? entry.sAMAccountName.toLowerCase()
        : usernameClean.toLowerCase();

      const firstName = typeof entry.givenName === 'string'
        ? entry.givenName
        : typeof entry.displayName === 'string'
          ? entry.displayName.split(' ')[0]
          : username;

      const lastName = typeof entry.sn === 'string'
        ? entry.sn
        : typeof entry.displayName === 'string' && entry.displayName.split(' ').length > 1
          ? entry.displayName.split(' ').slice(1).join(' ')
          : 'User';

      return {
        dn: userDn,
        email: mail,
        username,
        firstName,
        lastName,
      };
    } catch (err: any) {
      console.warn(`[LDAP] Auth failed for ${identifier}: ${err?.message || err}`);
      try {
        await client.unbind();
      } catch {}
      return null;
    }
  }
}
