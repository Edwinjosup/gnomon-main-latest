#!/usr/bin/env bash
set -euo pipefail
cd /opt/gnomon-main

python3 - <<'PY'
from pathlib import Path

m = Path("apps/api/src/modules/timecard/work-session.model.ts")
t = m.read_text()
if "location" not in t:
    t = t.replace(
        "  shiftCode: ShiftCode | null;\n",
        "  shiftCode: ShiftCode | null;\n  location: 'WFO' | 'WFH' | null;\n", 1)
    t = t.replace(
        "    shiftCode: {\n      type: String,\n      enum: ['M', 'R', 'A', 'N', null],\n      default: null,\n    },\n",
        "    shiftCode: {\n      type: String,\n      enum: ['M', 'R', 'A', 'N', null],\n      default: null,\n    },\n"
        "    location: {\n      type: String,\n      enum: ['WFO', 'WFH', null],\n      default: null,\n    },\n", 1)
    m.write_text(t)

s = Path("apps/api/src/modules/timecard/timecard.service.ts")
t = s.read_text()
t = t.replace("function toDto(session: WorkSessionDocument & { location?: string }): WorkSessionDto {",
              "function toDto(session: WorkSessionDocument): WorkSessionDto {")
s.write_text(t)
PY

grep -n "location" apps/api/src/modules/timecard/work-session.model.ts
docker compose up -d --build api
EOF